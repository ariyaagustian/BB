
TITLE: 
Medcare - Free HTML5 Bootstrap Template for Medical and Health Websites

AUTHOR:
DESIGNED & DEVELOPED by QBOOTSTRAP.COM

Website: 		http://qbootstrap.com/
Twitter: 		http://twitter.com/Q_bootstrap
Facebook: 		https://www.facebook.com/Qbootstrap



CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

jQuery Easing
http://gsgd.co.uk/sandbox/jquery/easing/

Modernizr
http://modernizr.com/

Google Fonts
https://www.google.com/fonts/

Icomoon
https://icomoon.io/app/

Respond JS
https://github.com/scottjehl/Respond/blob/master/LICENSE-MIT

animate.css
http://daneden.me/animate

jQuery Waypoint
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt

Flexslider
http://www.woothemes.com/flexslider/

Owl Carousel
http://www.owlcarousel.owlgraphic.com/

jQuery countTo
http://www.owlcarousel.owlgraphic.com/

Magnific Popup
http://dimsemenov.com/plugins/magnific-popup/

Google Map
https://developers.google.com/maps/documentation/javascript/reference#MapOptions

Sticky Kit
http://leafo.net

Demo Images:
http://unsplash.com
http://pexel.com
http://picjumbo.com

